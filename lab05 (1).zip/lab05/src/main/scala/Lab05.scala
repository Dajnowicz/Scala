object Lab05 extends App {
  // program głóewny – tutaj przetestuj swoją implementację MyList
}
