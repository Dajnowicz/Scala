abstract class MyList[A] {
    def head: A
    def tail: MyList[A]
    def isEmpty: Boolean
    def add(a: A): MyList[A]
}
/*
  Zadanie 1: Pusta lista powinna być jedna. Jak to zrobić?
  Wskazówka: dla dowolnego typu X w Scali mamy „Nothing <: X”
*/
class MyEmptyList[A] extends MyList[A] {
    def head: A = throw new NoSuchElementException
    def tail: MyList[A] = throw new NoSuchElementException
    def isEmpty: Boolean = true
    def add(a: A): MyList[A] = new MyNonEmptyList[A](a, this)
}
class MyNonEmptyList[A](h: A, t: MyList[A]) extends MyList[A] {
    def head: A = h
    def tail: MyList[A] = t
    def isEmpty: Boolean = false
    def add(a: A): MyList[A] = new MyNonEmptyList[A](a, this)
}
/*
  Zadanie 2: Spowoduj, żeby możliwe było definiowanie list tak, jak poniżej?

  MyList()
  MyList(1, 2, 3)
*/

/*
  Zadanie 3: Zdefiniuj (przesłoń) metodę toString dla klasy MyList tak, żeby
  produkowała napisy postaci „[el1, ... , eln]”.
*/
