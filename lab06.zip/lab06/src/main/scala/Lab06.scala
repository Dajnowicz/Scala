import akka.actor.{Actor, ActorLogging, Props, ActorSystem}
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext

case object Tick

class Ship(x: Int, y: Int, val dim: Int) extends Actor with ActorLogging {
  var posX = x
  var posY = y

  def receive: Receive = {
    case Tick =>
      log.info(s"[${self.path.name}] ($x, $y)")
  }

}
object Ship {
  def props(x: Int, y: Int, dim: Int): Props = {
    Props(classOf[Ship], x, y, dim)
  }
}

object Demo extends App {

  val system = ActorSystem("DispDemo")
  // wprowadźmy sobie skrótową nazwę na „planistę” systemowego:
  val scheduler = system.scheduler

  val r = new util.Random()
  val dim = 50

  val actors = for (i <- 1 to 10) {
    val x = r.nextInt(dim) // jako losowo zmieniać znak
    val y = r.nextInt(dim) // jakoś losowo zmieniać znak
    system.actorOf(Ship.props(x, y, dim), s"ship$i")
  }

  /*
    Operacjom które wymagają wykorzystania wątków, a taką
    jest cykliczne wysyłanie wiadomości, musimy dostarczyć
    domyślne źródło wątków – tzw. „kontekst wykonawczy”.
    Można to zrobić na kilka sposobów:
  */
  import ExecutionContext.Implicits.global
  /*
    powyższe jest równoważne zdefiniowaniu „niejawnego kontekstu”:

    implicit val ec: ExecutionContext = ExecutionContext.global

    Mając do dyspozycji system aktorów możemy też użyć jego „dyspozytora”
    jako kontektu wykonawczego:

    import system.dispatcher

    Obie powyższe możliwości są dobre w naszym przypadku, ale w sytuacji
    gdy operacja może zablokować wątek warto użyć kontekstu wykonawczego
    stworzonego specjalnie do tego celu – patrz dokumentacja Akki, hasło
    „Dedicated dispatcher for blocking operations”.
  */
  val cancellable = scheduler.scheduleWithFixedDelay(1.seconds, 350.milliseconds) {
    new Runnable {
      def run(): Unit = {
        system.actorSelection("/user/ship*") ! Tick
      }
    }
  }

}
